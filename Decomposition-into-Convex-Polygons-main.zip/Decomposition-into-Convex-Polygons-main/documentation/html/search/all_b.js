var searchData=
[
  ['vertex_0',['Vertex',['../struct_vertex.html',1,'']]]
];
