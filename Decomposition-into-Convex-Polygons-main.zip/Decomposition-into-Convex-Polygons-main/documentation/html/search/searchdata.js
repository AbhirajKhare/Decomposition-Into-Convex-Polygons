var indexSectionsWithContent =
{
  0: "adefhimnoptv",
  1: "dfhv",
  2: "aefimnopt"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions"
};

