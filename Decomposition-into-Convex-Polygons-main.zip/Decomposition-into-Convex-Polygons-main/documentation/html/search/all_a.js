var searchData=
[
  ['time_5freq_0',['time_req',['../classdecompose__polygon.html#a02059c1ac03530048b803ef51516f893',1,'decompose_polygon']]]
];
