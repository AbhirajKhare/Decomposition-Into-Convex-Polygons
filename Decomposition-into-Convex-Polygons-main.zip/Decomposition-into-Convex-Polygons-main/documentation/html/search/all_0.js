var searchData=
[
  ['add_5fface_0',['add_face',['../class_d_c_e_l.html#ad37ecf82b0beaf62b6d360621de180af',1,'DCEL']]],
  ['add_5fhalfedge_1',['add_halfedge',['../class_d_c_e_l.html#ae04241953fa121e3a03e6a61f0776932',1,'DCEL']]],
  ['add_5fvertex_2',['add_vertex',['../class_d_c_e_l.html#a86b8f601f3a20b300579578655463056',1,'DCEL']]]
];
