var annotated_dup =
[
    [ "DCEL", "class_d_c_e_l.html", "class_d_c_e_l" ],
    [ "decompose_polygon", "classdecompose__polygon.html", "classdecompose__polygon" ],
    [ "Face", "struct_face.html", null ],
    [ "Halfedge", "struct_halfedge.html", null ],
    [ "Vertex", "struct_vertex.html", null ]
];